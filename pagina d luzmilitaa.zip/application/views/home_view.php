<!-- INICIO TEST -->
                            <div class="portlet box blue">
                                <div class="portlet-title">
                                    <div class="caption"><i class="fa fa-desktop"></i>Pulido del servidor</div>
                                </div>
                                <div class="portlet-body form">
                                    <form id="form_certtest" name="form_certtest" action="<?php echo base_url(); ?>certificar/test/validar_etest" method="post">
                                        <div class="form-body"><?php
                                            $i = 0;
                                            foreach ($preguntas as $preg) :
                                                $i++;
                                                ?>
                                                <?php 
                                            endforeach;
                                            ?>
                                            <p>El servidor se encuentra abierto, la IP es: <b>74.91.126.218:8000</b> pero aún se están puliendo los últimos detalles, si encuentras algún error reportalo en la sección correspondiente, es posible que los encuentres debido a que al ser un servidor creado desde cero y ser la primera vez que está online, muchas cosas deben ser cambiadas antes de ser publicado a todos. Disculpen los inconvenientes, todos serán arreglados.</p>
                                         	<p></p>

                                        </div>
                                       
                                        <div class="form-actions right">
                                            <div class="col-md-offset-3 col-md-9">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- FIN TEST -->

<!-- INICIO TEST -->
                            <div class="portlet box blue">
                                <div class="portlet-title">
                                    <div class="caption"><i class="fa fa-comments-o"></i>Soporte</div>
                                </div>
                                <div class="portlet-body form">
                                    <form id="form_certtest" name="form_certtest" action="<?php echo base_url(); ?>certificar/test/validar_etest" method="post">
                                        <div class="form-body"><?php
                                            $i = 0;
                                            foreach ($preguntas as $preg) :
                                                $i++;
                                                ?>
                                                <?php 
                                            endforeach;
                                            ?>
                                            <p>El soporte es una sección en el foro donde podrás colocar cualquier problema o inquietud que tengas y un usuario o un administrador te solucionará el problema.</p>
                                         	<p></p>
                                            <center><button type="submit" class="btn green" data-loading-text="Redirigiéndote al soporte"><i class="fa fa-archive"></i> <a href="http://wattsrp.com/foro/index.php?board=9.0" style="color:white">Ir al soporte</a></button></center>

                                        </div>
                                       
                                        <div class="form-actions right">
                                            <div class="col-md-offset-3 col-md-9">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- FIN TEST -->

                             <!-- INICIO TEST -->
                            <div class="portlet box blue">
                                <div class="portlet-title">
                                    <div class="caption"><i class="fa fa-money"></i>Tienda Online</div>
                                </div>
                                <div class="portlet-body form">
                                    <form id="form_certtest" name="form_certtest" action="<?php echo base_url(); ?>certificar/test/validar_etest" method="post">
                                        <div class="form-body"><?php
                                            $i = 0;
                                            foreach ($preguntas as $preg) :
                                                $i++;
                                                ?>
                                                <?php 
                                            endforeach;
                                            ?>
                                            <p><b>Tienda Online</b>: Contamos con una tienda online donde podrás comprar Coins, los cuales se pueden gastar de distintas formas.</p>
                                         	<p>Comprando Coins contribuyes a pagar los gastos del servidor.</p>
                                            <center><button type="submit" class="btn green" data-loading-text="Redirigiéndote a la tienda"><i class="fa fa-money"></i> <a href="http://wattsrp.com/tienda" style="color:white"> Tienda Online</a></button></center>

                                        </div>
                                       
                                        <div class="form-actions right">
                                            <div class="col-md-offset-3 col-md-9">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- FIN TEST -->